#### Discovery

##### Version 1.1.2
1. fix no LatestTimestamp when register
2. fix param split bug
3. update go mod

##### Version 1.1.1
1. fix initproject abort

##### Version 1.1.0
1. use kratos pkg
2. replace gin by kratos/bm
3. fix poll return nil when be canceled.
4. add init protect mode
5. supoort set.

##### Version 1.0.2
1.fix nodesproc. get all zone nodes.

##### Version 1.0.1
1.rename import path

##### Version 1.0.0
1. discovery register&polls&replica
2. self-discovering nodes
3. metadata updates
4. naming client & grpc resolver
